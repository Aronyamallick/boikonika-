# বই কণিকা (Boi Konika)

Bengali-language book marketplace + e-book reader — built with React, Vite, and Tailwind.

## GitHub-এ upload করার নিয়ম

1. এই পুরো folder-এর সব file download করো।
2. তোমার repo (Boi-konika) খুলে **Add file → Upload files** চাপো।
3. এই সব file/folder drag করে দাও:
   - `index.html`
   - `package.json`
   - `vite.config.js`
   - `tailwind.config.js`
   - `postcss.config.js`
   - `.gitignore`
   - পুরো `src` folder (main.jsx, App.jsx, index.css সমেত)
4. নিচে "Commit changes" চাপো।

## Vercel দিয়ে live করার নিয়ম

1. [vercel.com](https://vercel.com) গিয়ে GitHub দিয়ে sign in করো।
2. **Add New → Project** চাপো।
3. `Boi-konika` repo select করো।
4. Framework "Vite" auto-detect হবে — কিছু বদলাতে হবে না।
5. **Deploy** চাপো। ২-৩ মিনিটে একটা লিংক পাবে যেটা ফোনে খোলে।
